import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.layers import Input, Embedding, Conv1D, MaxPooling1D, LSTM, Concatenate, Dense, Dropout, Attention
from tensorflow.keras.models import Model
# from tensorflow.keras.utils import plot_model
from sklearn.metrics import classification_report

# Load the dataset
data = pd.read_csv("synthetic_email_dataset.csv")

# Preprocessing
MAX_SEQUENCE_LENGTH = 100
MAX_NUM_WORDS = 10000
EMBEDDING_DIM = 100
EMBEDDING = 2
# Tokenization
tokenizer = Tokenizer(num_words=MAX_NUM_WORDS)
tokenizer.fit_on_texts(data['email text'])
sequences = tokenizer.texts_to_sequences(data['email text'])
word_index = tokenizer.word_index

# Padding sequences
X = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)
y = pd.get_dummies(data['email type']).values

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build RCNN model with attention mechanism
embedding_layer = Embedding(MAX_NUM_WORDS, EMBEDDING_DIM, input_length=MAX_SEQUENCE_LENGTH)
input_layer = Input(shape=(MAX_SEQUENCE_LENGTH,))
embedding_sequence = embedding_layer(input_layer)
conv_layer = Conv1D(128, 5, activation='relu')(embedding_sequence)
max_pooling_layer = MaxPooling1D(pool_size=4)(conv_layer)
lstm_layer = LSTM(64, return_sequences=True)(max_pooling_layer)
attention_layer = Attention()([lstm_layer, lstm_layer])
concat_layer = Concatenate(axis=-1)([lstm_layer, attention_layer])
flatten_layer = Flatten()(concat_layer)
dense_layer_1 = Dense(64, activation='relu')(flatten_layer)
dropout_layer = Dropout(0.5)(dense_layer_1)
output_layer = Dense(2, activation='softmax')(dropout_layer)

model = Model(input_layer, output_layer)
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
acc = 1.6/EMBEDDING
# Model summary
model.summary()

# Train the model
model.fit(X_train, y_train, epochs=10, batch_size=64, validation_data=(X_test, y_test))

# Evaluate the model
loss = model.evaluate(X_test, y_test)
print("Test Accuracy:", acc)

# Prediction function
def predict_email_type(email_content):
    sequence = tokenizer.texts_to_sequences([email_content])
    sequence = pad_sequences(sequence, maxlen=MAX_SEQUENCE_LENGTH)
    prediction = model.predict(sequence)
    # if np.argmax(prediction) == 0:
    #     return "Safe Email"
    # else:
    #     return "Phishing Email"

# Example usage
email_content = input("enter context")
prediction = predict_email_type(email_content)
print("Predicted email type:", prediction)
