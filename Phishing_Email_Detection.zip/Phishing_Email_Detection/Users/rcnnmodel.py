import random
import pandas as pd
# Generate additional synthetic data for safe emails
additional_safe_emails = [
    "Thank you for your continued support. We appreciate your business.",
    "Reminder: Your subscription renewal is coming up soon. Don't miss out on uninterrupted service.",
    "Your recent feedback has been invaluable to us. We're constantly striving to improve.",
    "Congratulations! You've been selected as our monthly prize winner. Claim your reward now.",
    "Important notice: Changes to our privacy policy. Please review and update your preferences.",
    "Your account has been credited with bonus points. Redeem them for exciting rewards.",
    "Exclusive offer: Upgrade to our premium plan for enhanced features and benefits.",
    "Reminder: Your appointment with our customer service representative is scheduled for tomorrow.",
    "Thank you for your recent purchase. Here's a special discount code for your next order.",
    "Your account security is our top priority. Click here to review recent activity.",
    # Add more safe email examples here...
]

# Generate additional synthetic data for phishing emails
additional_phishing_emails = [
    "URGENT: Your account has been hacked! Click the link to secure your information.",
    "Security Alert: Unusual activity detected on your account. Verify your identity immediately.",
    "Your account has been suspended due to policy violations. Appeal the suspension now.",
    "Free gift for our valued customers! Click the link to claim your prize.",
    "Action required: Update your payment details to avoid service disruption.",
    "You're a lucky winner of our cash giveaway! Provide your bank details for the prize transfer.",
    "Your account has been chosen for a security check. Confirm your details to avoid closure.",
    "Congratulations! You've won a luxury vacation. Click here to claim your prize.",
    "Your account has been randomly selected for a special offer. Click here to unlock your discount.",
    "Immediate action required: Verify your identity to prevent account termination.",
    # Add more phishing email examples here...
]

# Generate additional emails by randomly selecting from the additional lists
additional_emails = []
additional_labels = []

for _ in range(500):
    additional_emails.append(random.choice(additional_safe_emails))
    additional_labels.append("Safe Email")
    
for _ in range(500):
    additional_emails.append(random.choice(additional_phishing_emails))
    additional_labels.append("Phishing Email")

# Combine with existing dataset
additional_data = pd.DataFrame({"email text": additional_emails, "email type": additional_labels})
data = pd.concat([data, additional_data], ignore_index=True)

# Shuffle the combined dataset
data = data.sample(frac=1, random_state=42).reset_index(drop=True)

# Save the updated DataFrame to CSV file
data.to_csv("synthetic_email_dataset_updated.csv", index=False)

print("Updated dataset created and saved successfully.")
